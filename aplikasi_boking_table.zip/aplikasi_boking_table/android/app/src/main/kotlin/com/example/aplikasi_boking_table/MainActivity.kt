package com.example.aplikasi_boking_table

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
